#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: scripts/update-html.sh /path/to/index.html" >&2
  exit 1
fi
source_file="$1"
if [ ! -f "$source_file" ]; then
  echo "Source index.html not found: $source_file" >&2
  exit 1
fi
cp "$source_file" "app/src/main/assets/index.html"
echo "Updated app/src/main/assets/index.html"
