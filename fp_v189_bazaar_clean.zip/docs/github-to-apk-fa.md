# راهنمای ساخت APK FitPlus اشتراکی v185 با GitHub

این بسته مخصوص پروژه مشتری است و هیچ ابزار مدیریتی داخل آن قرار ندارد.

## ۱) محتویات ZIP را باز کن

فایل ZIP را Extract کن. داخل آن باید این موارد را ببینی:

- `.github`
- `app`
- `docs`
- `scripts`
- `README.md`
- `build.gradle`
- `settings.gradle`
- `VERSION.txt`

خود ZIP را داخل GitHub آپلود نکن؛ محتوای داخل ZIP را آپلود کن.

## ۲) Repository جدید یا همین repository را باز کن

در GitHub وارد repository مشتری شو. اگر repository خالی است، از بخش Quick setup روی لینک زیر بزن:

`uploading an existing file`

اگر repository خالی نیست، از صفحه Code روی `Add file` و بعد `Upload files` بزن.

## ۳) فایل‌ها را آپلود کن

همه فایل‌ها و پوشه‌های داخل ZIP بازشده را انتخاب و آپلود کن.

خیلی مهم: پوشه `.github` باید آپلود شود. مسیر زیر باید در repository وجود داشته باشد:

`.github/workflows/build-apk.yml`

بدون این فایل، تب Actions نمی‌تواند APK بسازد.

## ۴) Commit کن

در پیام commit بنویس:

`upload fitplus subscription apk builder v185`

بعد روی `Commit changes` بزن.

## ۵) ساخت APK از Actions

به تب `Actions` برو. اگر GitHub اجازه خواست، workflowها را Enable کن.

Workflow زیر را انتخاب کن:

`Build FitPlus Subscription APK`

بعد روی `Run workflow` بزن.

## ۶) دانلود APK

وقتی build سبز شد، وارد همان run شو و پایین صفحه از بخش Artifacts فایل زیر را دانلود کن:

`fitplus-sub-v185-apk`

داخل آن این APK قرار دارد:

`fitplus-sub-v185-debug.apk`

## ۷) نکته امنیتی

کدساز مدیر، فایل تولید کد فعال‌سازی، کلیدها، رمزها یا هر ابزار مدیریتی را در این repository آپلود نکن.
این ابزارها باید فقط نزد مدیر بمانند و جدا از پروژه مشتری نگهداری شوند.
